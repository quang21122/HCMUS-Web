Các bước up dữ liệu lên MongoDB:
- Bước 1: Chạy my_crawler.py để lấy bài báo về và chạy tiếp remove_dups.py để loại bỏ các url giống nhau. Url các bài báo nằm trong file news.csv
- Bước 2: crawler.json sẽ được bỏ bớt đường dẫn ứng với mỗi tag
- Bước 3: Chạy script trên MongoDB Playground để lần lượt lấy category và tag về và lưu vào file json
    + Đối với category: Category đứng đầu sẽ là parent của các category còn lại. Nhóm dùng ChatGPT để tạo ra file json chứa category và từng parent nếu có
    + Sau khi đã chuẩn bị xong 2 file json chứa các category và các tag, Nhóm load file lên và up lên MongoDB bằng MongoDB Playground
- Bước 4: Chạy script trên MongoDB Playground để lấy về 2 file json categories.json và tags.json và crawler-1.json
- Bước 5: Dùng 2 script category.js và tags.js để sửa lại dữ liệu trên collection crawler-1.json thành các id thay vì name
- Bước 6: Dùng ChatGPT lấy ra danh sách author từ các article, và dùng script authorAdder.js để thêm author vào 1 collection riêng và sửa lại trường author của từng article thành id

Các dữ liệu còn lại được tạo ra sau khi đã có các Models và Services, và được upload thông qua quá trình phát triển (tạo bằng tay) và kiểm thử ứng dụng (dùng Postman)