Lưu ý khi code frontend:
    Cần chạy song song 2 lệnh là npm run build:css và npm run dev